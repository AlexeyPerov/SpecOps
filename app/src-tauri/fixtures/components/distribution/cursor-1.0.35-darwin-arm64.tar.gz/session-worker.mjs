SpecOps local fixture; synthetic data, no vendor software.
